// require([
//   'thought'
// ], function($){

// });

console.log("piles of awesome");
